function doFirst(){
    // 先跟 HTML 畫面產生關連，再建事件聆聽功能

    // document.getElementById('theForm').onsubmit = submitData

    document.getElementById('toggle').onchange = toggleCheckbox
}
function toggleCheckbox(){
    let toggleStatus = document.getElementById('toggle').checked

    let checkboxes = document.querySelectorAll(`input[type="checkbox"]`)
    for(let i = 1; i < checkboxes.length; i++){
        checkboxes[i].checked = toggleStatus
    }
}
window.addEventListener('load', doFirst)